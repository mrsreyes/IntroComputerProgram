/*Makayla Steinmetz 03-09-2019*/
var user = 10;
var counter = 0;
var max = 5;
var answers = ['Sorry', 'Try Again', 'Opps'];
var answer = answers[Math.floor(Math.random()*answers.length)];

var randomNum = Math.floor(Math.random() * user) + 1;

while (attempts != randomNum) {
	var attempts = prompt("Please pick a number between 1 and " + user);
	counter += 1;
	
	if(counter > max){
	document.write("<p>" + answer + "! the Correct Number was " + randomNum + ". Please Play Again!</p>");
	break;
	}
	
	if(attempts == randomNum){
		document.write("Correct!");
		document.write("<p>The Correct Number is" + randomNum + "</p>");
		document.write("<p>It took you" + attempts + "to get the correct number</p>");
	}
}
